## 阿里云视频云web上传demo

### 启动项目

```sh
npm run dev
```

### 项目打包

```sh
npm run build
```

打包之后将 lib 目录拷贝到 dist 目录下